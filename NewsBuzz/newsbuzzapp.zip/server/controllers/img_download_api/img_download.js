const express = require("express");
// const router = express.Router();
const jobs_news = require("../../models/jobs_model");

var fs = require("fs");
var request = require("request");

exports.readJobs = async (req, res) => {
  
};
